import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns



#CARICAMENTO DEL DATASET


dati = pd.read_csv(
    "train_FD001.txt",
    sep=r"\s+",
    header=None
)

print("Dimensione dataset:")
print(dati.shape)



#NOMI DELLE COLONNE


nomi_colonne = [
    "unit",
    "cycle",
    "setting1",
    "setting2",
    "setting3",
    "sensor1",
    "sensor2",
    "sensor3",
    "sensor4",
    "sensor5",
    "sensor6",
    "sensor7",
    "sensor8",
    "sensor9",
    "sensor10",
    "sensor11",
    "sensor12",
    "sensor13",
    "sensor14",
    "sensor15",
    "sensor16",
    "sensor17",
    "sensor18",
    "sensor19",
    "sensor20",
    "sensor21"
]

dati.columns = nomi_colonne



#PRIME RIGHE DEL DATASET


print("\nPrime 5 righe:")
print(dati.head())



#INFORMAZIONI GENERALI


print("\nInformazioni sul dataset:")
print(dati.info())



#NUMERO DI MOTORI


numero_motori = dati["unit"].nunique()

print("\nNumero di motori:")
print(numero_motori)



#ELENCO DEI MOTORI


print("\nMotori presenti:")
print(dati["unit"].unique())



#CICLO MASSIMO DI OGNI MOTORE


vita_motori = dati.groupby("unit")["cycle"].max()

print("\nNumero di cicli di ogni motore:")
print(vita_motori)



#CREAZIONE DELLA RUL


dati["RUL"] = (
    dati.groupby("unit")["cycle"].transform("max")
    - dati["cycle"]
)

print("\nPrime righe con la RUL:")
print(dati[["unit", "cycle", "RUL"]].head(10))



#CONTROLLO DELLA RUL DEL MOTORE 1


motore1 = dati[dati["unit"] == 1]

print("\nUltimi cicli del motore 1:")
print(
    motore1[["unit", "cycle", "RUL"]].tail()
)



#ELENCO DEI SENSORI


sensori = [
    "sensor1",
    "sensor2",
    "sensor3",
    "sensor4",
    "sensor5",
    "sensor6",
    "sensor7",
    "sensor8",
    "sensor9",
    "sensor10",
    "sensor11",
    "sensor12",
    "sensor13",
    "sensor14",
    "sensor15",
    "sensor16",
    "sensor17",
    "sensor18",
    "sensor19",
    "sensor20",
    "sensor21"
]



#STATISTICHE DEI SENSORI


print("\nStatistiche dei sensori:")
print(dati[sensori].describe())



#VARIANZIONE STANDARD DEI SENSORI


varianze = dati[sensori].var()

print("\nVarianza dei sensori:")
print(varianze.sort_values())



#GRAFICO DELLA RUL DEL MOTORE 1


plt.figure(figsize=(10, 5))

plt.plot(
    motore1["cycle"],
    motore1["RUL"]
)

plt.xlabel("Ciclo")
plt.ylabel("RUL")
plt.title("Remaining Useful Life - Motore 1")

plt.grid()

plt.show()



#GRAFICO DI SENSOR4 DEL MOTORE 1


plt.figure(figsize=(10, 5))

plt.plot(
    motore1["cycle"],
    motore1["sensor4"]
)

plt.xlabel("Ciclo")
plt.ylabel("Sensor 4")
plt.title("Sensor 4 - Motore 1")

plt.grid()

plt.show()



#GRAFICI DI TUTTI I SENSORI DEL MOTORE 1


for sensore in sensori:

    plt.figure(figsize=(10, 4))

    plt.plot(
        motore1["cycle"],
        motore1[sensore]
    )

    plt.xlabel("Ciclo")
    plt.ylabel(sensore)
    plt.title(f"{sensore} - Motore 1")

    plt.grid()

    plt.show()



#CORRELAZIONE DEI SENSORI CON LA RUL


correlazioni = (
    dati[sensori + ["RUL"]]
    .corr()["RUL"]
)

print("\nCorrelazione dei sensori con la RUL:")
print(correlazioni.sort_values())



#HEATMAP DELLE CORRELAZIONI


plt.figure(figsize=(12, 8))

sns.heatmap(
    dati[sensori + ["RUL"]].corr(),
    cmap="coolwarm"
)

plt.title("Matrice di correlazione")


plt.show()

#CANDIDATI PER UTILIZZO COME VARIABILI DI INPUT

sensori_interessanti = [
    "sensor11",
    "sensor4",
    "sensor12",
    "sensor7"
]

for sensore in sensori_interessanti:

    plt.figure(figsize=(8, 5))

    plt.scatter(
        dati[sensore],
        dati["RUL"],
        s=5
    )

    plt.xlabel(sensore)
    plt.ylabel("RUL")
    plt.title(f"{sensore} vs RUL")

    plt.grid()

    plt.show()

#ORA ESCLUDO I SENSORI COSTANTI E MANTENGO GLI ALTRI COME POSSIBILI VARIABILI DI INPUT DEL MODELLO

sensori_utili = [
    "sensor2",
    "sensor3",
    "sensor4",
    "sensor6",
    "sensor7",
    "sensor8",
    "sensor9",
    "sensor11",
    "sensor12",
    "sensor13",
    "sensor14",
    "sensor15",
    "sensor17",
    "sensor20",
    "sensor21"
]

#SPLIT MOTORI 80 PER TRAIN E 20 PER VALIDATION

from sklearn.model_selection import train_test_split

motori = dati["unit"].unique()

motori_train, motori_val = train_test_split(
    motori,
    test_size=0.2,
    random_state=42
)

dati_train = dati[
    dati["unit"].isin(motori_train)
]

dati_val = dati[
    dati["unit"].isin(motori_val)
]

print("\nMotori training:", dati_train["unit"].nunique())
print("Motori validation:", dati_val["unit"].nunique())


#CREAZIONE X E Y


X_train = dati_train[sensori_utili]
y_train = dati_train["RUL"]

X_val = dati_val[sensori_utili]
y_val = dati_val["RUL"]

print("\nDimensione X_train:", X_train.shape)
print("Dimensione y_train:", y_train.shape)

print("Dimensione X_val:", X_val.shape)
print("Dimensione y_val:", y_val.shape)


#IMPLEMENTAZIONE REGRESSIONE LINEARE

from sklearn.linear_model import LinearRegression

modello_lineare = LinearRegression()

modello_lineare.fit(
    X_train,
    y_train
)


y_pred = modello_lineare.predict(X_val)



#VALUTAZIONE ERRORE


from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
import numpy as np

mae = mean_absolute_error(
    y_val,
    y_pred
)

rmse = np.sqrt(
    mean_squared_error(
        y_val,
        y_pred
    )
)

print("\n===== RISULTATI LINEAR REGRESSION =====")

print("MAE:", mae)
print("RMSE:", rmse)



#GRAFICO RUL REALE VS RUL PREDDETTA


plt.figure(figsize=(8, 6))

plt.scatter(
    y_val,
    y_pred,
    s=10
)

plt.plot(
    [0, y_val.max()],
    [0, y_val.max()]
)

plt.xlabel("RUL reale")
plt.ylabel("RUL predetta")
plt.title("Linear Regression - RUL reale vs predetta")

plt.grid()

plt.show()

#CONSIDERAZIONI: IN VALIDATION QUESTO MODELLO SBAGLIA MEDIAMENTE DI 30 CICLI, IL VALORE RMSE DI 38 INDICA LA PRESENZA DI ALCUNE PREDICTION CON UN ERRORE PIUTTOSTO ALTO.
#ORA SI PROCEDE CON L'IMPLEMENTAZIONE DEL MODELLO RANDOM FOREST (200 alberi decisionali e rul che sarà un media delle predizioni) IN MODO DA POTER CONFRONTARE I RISULTATI.

from sklearn.ensemble import RandomForestRegressor

modello_rf = RandomForestRegressor(
    n_estimators=200,  #200 alberi e 42 random states sono numeri arbitrari
    random_state=42,
    n_jobs=-1
)

#ADDESTRAMENTO

modello_rf.fit(
    X_train,
    y_train
)

y_pred_rf = modello_rf.predict(X_val)

#STAMPA MAE E RMSE
mae_rf = mean_absolute_error(
    y_val,
    y_pred_rf
)

rmse_rf = np.sqrt(
    mean_squared_error(
        y_val,
        y_pred_rf
    )
)

print("\n===== RISULTATI RANDOM FOREST =====")

print("MAE:", mae_rf)
print("RMSE:", rmse_rf)

#VISUALIZZAZIONE PREDIZIONI RANDOM FOREST

plt.figure(figsize=(8, 6))

plt.scatter(
    y_val,
    y_pred_rf,
    s=10
)

plt.plot(
    [0, y_val.max()],
    [0, y_val.max()]
)

plt.xlabel("RUL reale")
plt.ylabel("RUL predetta")
plt.title("Random Forest - RUL reale vs predetta")

plt.grid()

plt.show()

#POSSIAMO SFRUTTARE UN PROPRIETA' DI RANDOM FOREST PER VISUALIZZARE L'IMPORTANZA DEI SENSORI NELLE DECISIONI DEL MODELLO

importanze = pd.DataFrame({
    "sensore": sensori_utili,
    "importanza": modello_rf.feature_importances_
})

importanze = importanze.sort_values(
    "importanza",
    ascending=False
)

print("\nImportanza dei sensori:")
print(importanze)


#ORA IMPLEMENTO UN DECISION TREE REGRESSOR

from sklearn.tree import DecisionTreeRegressor

modello_tree = DecisionTreeRegressor(
    random_state=42
)

modello_tree.fit(
    X_train,
    y_train
)

#PREDIZIONI


y_pred_tree = modello_tree.predict(
    X_val
)

#VALUTAZIONE

mae_tree = mean_absolute_error(
    y_val,
    y_pred_tree
)

rmse_tree = np.sqrt(
    mean_squared_error(
        y_val,
        y_pred_tree
    )
)

print("\n===== RISULTATI DECISION TREE =====")

print("MAE:", mae_tree)
print("RMSE:", rmse_tree)

#CONFRONTO DEI TRE MODELLI

print("\n===== CONFRONTO MODELLI =====")

print(
    f"Linear Regression -> "
    f"MAE: {mae:.2f} | RMSE: {rmse:.2f}"
)

print(
    f"Decision Tree     -> "
    f"MAE: {mae_tree:.2f} | RMSE: {rmse_tree:.2f}"
)

print(
    f"Random Forest     -> "
    f"MAE: {mae_rf:.2f} | RMSE: {rmse_rf:.2f}"
)